import React, {useState,useEffect} from 'react'
import  axios  from 'axios';
import s from "./Sexsex.module.css"
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import Card from './card/Card';


function Sexsex() {
    const [sex,setsex ] = useState([])
    useEffect(() => {
   axios.get("https://admin.taffeine.com/api/events").then((resps)=>{
    let alleve=resps.data.data
    setsex(alleve)
   console.log(alleve);

   })
    }, [])
  return (
    <OwlCarousel className='owl-theme' loop margin={10} items={3} nav>
   {sex.map((item,index)=>{
    return <Card 
    key={index}
    title={item.title}
    img={item.url}
    category={item.category}
    content={item.content}
    slug={item.slug}
    />



   })

   }
   
</OwlCarousel>

  )
}

export default Sexsex
